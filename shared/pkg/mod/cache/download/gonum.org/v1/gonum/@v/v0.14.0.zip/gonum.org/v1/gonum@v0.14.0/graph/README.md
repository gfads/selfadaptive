# Gonum graph

[![go.dev reference](https://pkg.go.dev/badge/gonum.org/v1/gonum/graph)](https://pkg.go.dev/gonum.org/v1/gonum/graph)
[![GoDoc](https://godocs.io/gonum.org/v1/gonum/graph?status.svg)](https://godocs.io/gonum.org/v1/gonum/graph)

This is a generalized graph package for the Go language.
